# ==================== 0. Import Libraries ====================
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import BertTokenizer, BertModel
from tqdm import tqdm
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score, f1_score
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier, plot_tree, _tree
from sklearn.metrics.pairwise import cosine_similarity
import matplotlib.pyplot as plt
from collections import Counter
import joblib
import os
import pickle
from random import sample
import seaborn as sns  # For better plots
from openpyxl import Workbook  # For Excel formatting (if using Excel output)
from openpyxl.styles import PatternFill, Font  # For highlighting in Excel

# ==================== 1. Load Data ====================
data_path = r"C:\Users\acer\Desktop\VAE 3\UNSC.xlsx"
if not os.path.exists(data_path):
    raise FileNotFoundError(f"Excel file not found: {data_path}")

df = pd.read_excel(data_path)
labels = df.iloc[:, 0].astype(str).tolist()
texts = df.iloc[:, 1].astype(str).tolist()

# Define save_dir early for consistent plot/model saving
save_dir = os.path.dirname(data_path) if os.path.exists(data_path) else '.'
os.makedirs(save_dir, exist_ok=True)
print(f"Output directory: {save_dir}")

# ==================== 2. Get BERT embeddings ====================
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
bert = BertModel.from_pretrained('bert-base-uncased').to(device)
bert.eval()

def get_bert_cls(text, max_length=512):
    inputs = tokenizer(text, return_tensors='pt', max_length=max_length,
                       truncation=True, padding='max_length')
    inputs = {k: v.to(device) for k, v in inputs.items()}
    with torch.no_grad():
        outputs = bert(**inputs)
        cls_vec = outputs.last_hidden_state[:, 0, :].squeeze().cpu().numpy()
    return cls_vec

embedding_cache_file = os.path.join(save_dir, 'bert_embeddings.npy')
if os.path.exists(embedding_cache_file):
    print("Loading BERT embeddings from cache...")
    bert_vectors = np.load(embedding_cache_file)
else:
    print("Generating BERT embeddings...")
    bert_vectors = np.array([get_bert_cls(text) for text in tqdm(texts, desc="BERT Embedding")])
    np.save(embedding_cache_file, bert_vectors)
    print(f"BERT embeddings saved to {embedding_cache_file}")

le = LabelEncoder()
label_ids = le.fit_transform(labels)

# ==================== 3. Define VAE ====================
class VAE_LayerNorm(nn.Module):
    def __init__(self, input_dim, hidden_dim=128, latent_dim=64, dropout_rate=0.2):
        super(VAE_LayerNorm, self).__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_dim*2), nn.LayerNorm(hidden_dim*2),
            nn.LeakyReLU(0.2), nn.Dropout(dropout_rate),
            nn.Linear(hidden_dim*2, hidden_dim), nn.LayerNorm(hidden_dim),
            nn.LeakyReLU(0.2), nn.Dropout(dropout_rate)
        )
        self.fc_mu = nn.Linear(hidden_dim, latent_dim)
        self.fc_logvar = nn.Linear(hidden_dim, latent_dim)
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, hidden_dim), nn.LayerNorm(hidden_dim),
            nn.LeakyReLU(0.2), nn.Dropout(dropout_rate),
            nn.Linear(hidden_dim, hidden_dim*2), nn.LayerNorm(hidden_dim*2),
            nn.LeakyReLU(0.2), nn.Dropout(dropout_rate),
            nn.Linear(hidden_dim*2, input_dim)
        )

    def encode(self, x):
        hidden = self.encoder(x)
        return self.fc_mu(hidden), self.fc_logvar(hidden)

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def decode(self, z):
        return self.decoder(z)

    def forward(self, x):
        mu, logvar = self.encode(x)
        z = self.reparameterize(mu, logvar)
        return self.decode(z), mu, logvar

# ==================== 4. Train / Load VAE (with Loss Visualization) ====================
def train_vae(vectors, batch_size=64, epochs=80, learning_rate=1e-4,
              hidden_dim=128, latent_dim=64, beta=1.0,
              model_path='vae_model.pt', scaler_path='scaler.pkl'):
    scaler = StandardScaler()
    vectors_scaled = scaler.fit_transform(vectors)
    data_tensor = torch.tensor(vectors_scaled, dtype=torch.float32)
    loader = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(data_tensor),
                                         batch_size=min(batch_size, len(data_tensor)), shuffle=True)
    input_dim = vectors.shape[1]
    vae = VAE_LayerNorm(input_dim=input_dim, hidden_dim=hidden_dim, latent_dim=latent_dim).to(device)
    optimizer = torch.optim.Adam(vae.parameters(), lr=learning_rate)

    total_loss_history = []
    mse_loss_history = []
    kld_loss_history = []

    print("Starting VAE training...")
    for epoch in range(epochs):
        vae.train()
        total_loss_epoch = 0
        mse_loss_epoch = 0
        kld_loss_epoch = 0
        for (data,) in loader:
            data = data.to(device)
            optimizer.zero_grad()
            recon, mu, logvar = vae(data)

            MSE = F.mse_loss(recon, data, reduction='sum')
            KLD = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
            loss = MSE + beta * KLD

            loss.backward()
            optimizer.step()

            total_loss_epoch += loss.item()
            mse_loss_epoch += MSE.item()
            kld_loss_epoch += KLD.item()

        n_samples = len(loader.dataset)
        total_loss_history.append(total_loss_epoch / n_samples)
        mse_loss_history.append(mse_loss_epoch / n_samples)
        kld_loss_history.append(kld_loss_epoch / n_samples)

        if (epoch + 1) % 10 == 0:
            print(f"Epoch {epoch+1}/{epochs}, Total Loss: {total_loss_history[-1]:.4f}, "
                  f"MSE: {mse_loss_history[-1]:.4f}, KLD: {kld_loss_history[-1]:.4f}")

    print("VAE training finished.")

    # ==================== Plot Losses ====================
    plt.figure(figsize=(12, 6))
    plt.plot(range(1, epochs+1), total_loss_history, marker='o', linestyle='-', label='Total Loss')
    plt.plot(range(1, epochs+1), mse_loss_history, marker='x', linestyle='--', label='Reconstruction Loss (MSE)')
    plt.plot(range(1, epochs+1), kld_loss_history, marker='s', linestyle='-.', label='KL Divergence')
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.title("VAE Losses Over Epochs")
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.savefig(os.path.join(save_dir, 'vae_losses_plot.png'), dpi=300, bbox_inches='tight')
    plt.show()

    torch.save(vae.state_dict(), model_path)
    with open(scaler_path, 'wb') as f:
        pickle.dump(scaler, f)
    print(f"VAE model saved to {model_path}")
    print(f"Scaler saved to {scaler_path}")

    return vae, scaler

vae_model_path = os.path.join(save_dir, 'vae_model.pt')
scaler_path = os.path.join(save_dir, 'scaler.pkl')

if os.path.exists(vae_model_path) and os.path.exists(scaler_path):
    print("Loading VAE model and scaler from disk...")
    scaler = pickle.load(open(scaler_path, 'rb'))
    input_dim = bert_vectors.shape[1]
    vae = VAE_LayerNorm(input_dim=input_dim, hidden_dim=64, latent_dim=50).to(device)
    vae.load_state_dict(torch.load(vae_model_path, map_location=device))
    vae.eval()
else:
    vae, scaler = train_vae(bert_vectors, epochs=80, latent_dim=50, hidden_dim=64,
                            batch_size=32, model_path=vae_model_path, scaler_path=scaler_path)

# ==================== 5. Get Latent Vectors ====================
def get_latent_vectors(vae, vectors, scaler, batch_size=128):
    vae.eval()
    vectors_scaled = scaler.transform(vectors)
    all_latent = []
    with torch.no_grad():
        for i in range(0, len(vectors_scaled), batch_size):
            batch = torch.tensor(vectors_scaled[i:i+batch_size], dtype=torch.float32).to(device)
            mu, _ = vae.encode(batch)
            all_latent.append(mu.cpu().numpy())
    return np.vstack(all_latent)

latent_vectors = get_latent_vectors(vae, bert_vectors, scaler)
print(f"VAE latent vectors shape: {latent_vectors.shape}")

# ==================== 6. Decision Tree Evaluation ====================
X_train, X_test, y_train, y_test = train_test_split(
    latent_vectors, label_ids, test_size=0.3, random_state=42, stratify=label_ids
)

dt_classifier_eval = DecisionTreeClassifier(random_state=42)
dt_classifier_eval.fit(X_train, y_train)
y_pred = dt_classifier_eval.predict(X_test)

print(f"Accuracy: {accuracy_score(y_test, y_pred):.4f}")
print(f"F1 Score (Macro): {f1_score(y_test, y_pred, average='macro'):.4f}")
print(classification_report(y_test, y_pred, target_names=le.classes_, zero_division=0))

# ==================== 7. Feature Importance (Enhanced Visualization) ====================
feat_imp = pd.Series(dt_classifier_eval.feature_importances_,
                     index=[f'Dim {i}' for i in range(latent_vectors.shape[1])])
sorted_importances = feat_imp.sort_values(ascending=False)

# Modified: Top 15 dimensions (for 95% coverage based on cumulative plot)
top_15_dims = sorted_importances.head(15)
top_15_indices = [int(dim.split(' ')[1]) for dim in top_15_dims.index]
print("Top 15 important latent dimensions (by Gini importance):")
print(top_15_dims)

top_15_dimensions = {name: float(val) for name, val in top_15_dims.items()}

# Print number of dimensions for 95% cumulative importance
cum_importance = sorted_importances.cumsum() / sorted_importances.sum()
num_for_95pct = np.argmax(cum_importance >= 0.95) + 1
print(f"达到95%累积重要性的维度数: {num_for_95pct}")

# Existing vertical bar plot (all features)
plt.figure(figsize=(12, 6))
feat_imp.sort_values(ascending=False).plot(kind='bar')
plt.title("Decision Tree Feature Importance (Gini) - All Dimensions")
plt.ylabel("Importance")
plt.xlabel("Latent Dimensions")
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.savefig(os.path.join(save_dir, 'feature_importance_all_vertical.png'), dpi=300, bbox_inches='tight')
plt.show()

# Enhanced: Horizontal bar plot for top 20 (better readability, kept for completeness)
top_20 = sorted_importances.head(20)
plt.figure(figsize=(12, 8))
top_20.plot(kind='barh')
plt.title("Top 20 Latent Dimensions by Feature Importance (Gini)")
plt.xlabel("Importance")
plt.ylabel("Latent Dimensions")
plt.tight_layout()
plt.savefig(os.path.join(save_dir, 'feature_importance_top20_horizontal.png'), dpi=300, bbox_inches='tight')
plt.show()

# Enhanced: Cumulative importance plot
cumulative_importance = (top_20.cumsum() / top_20.sum()) * 100
plt.figure(figsize=(10, 6))
plt.plot(range(1, len(cumulative_importance) + 1), cumulative_importance, marker='o', linewidth=2, markersize=6)
plt.axhline(y=80, color='r', linestyle='--', label='80% Threshold (Pareto-like)')
plt.axhline(y=95, color='g', linestyle='--', label='95% Threshold')
plt.xlabel('Number of Top Features')
plt.ylabel('Cumulative Importance (%)')
plt.title('Cumulative Feature Importance of Top Dimensions')
plt.grid(True, alpha=0.3)
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(save_dir, 'cumulative_feature_importance.png'), dpi=300, bbox_inches='tight')
plt.show()

# Optional: Pie chart for top 15 (updated to match perturbation focus)
plt.figure(figsize=(12, 8))
top_15_dims.plot(kind='pie', autopct='%1.1f%%', startangle=90)
plt.title("Proportion of Importance in Top 15 Latent Dimensions")
plt.ylabel('')  # Remove y-label for pie
plt.tight_layout()
plt.savefig(os.path.join(save_dir, 'top15_feature_importance_pie.png'), dpi=300, bbox_inches='tight')
plt.show()

print(f"Feature importance plots saved to {save_dir}/")

plt.figure(figsize=(20, 10))
plot_tree(dt_classifier_eval,
          feature_names=[f'Dim {i}' for i in range(latent_vectors.shape[1])],
          class_names=le.classes_,
          filled=True,
          max_depth=3,
          fontsize=10)
plt.title("Decision Tree Top 3 Levels")
plt.savefig(os.path.join(save_dir, 'decision_tree_visualization.png'), dpi=300, bbox_inches='tight')
plt.show()

# ==================== 8. Feature Usage Statistics ====================
def count_feature_usage(tree: DecisionTreeClassifier):
    tree_ = tree.tree_
    feature_usage = tree_.feature
    used_features = feature_usage[feature_usage >= 0]
    counts = Counter(used_features)
    return counts

feature_counts = count_feature_usage(dt_classifier_eval)
print("\nFeature usage in all tree nodes:")
for idx, count in feature_counts.most_common():
    tag = " <-- top 15" if idx in top_15_indices else ""
    print(f"Dimension {idx}: used in {count} node(s){tag}")

def top_features_in_top_levels(tree: DecisionTreeClassifier, top_features, max_level=3):
    tree_ = tree.tree_
    feature = tree_.feature
    children_left = tree_.children_left
    children_right = tree_.children_right

    def traverse(node, level=0):
        if node == _tree.TREE_LEAF or level >= max_level:
            return []
        feats = [feature[node]] if feature[node] >= 0 else []
        return feats + traverse(children_left[node], level+1) + traverse(children_right[node], level+1)

    used_features = traverse(0)
    top_count = sum(1 for f in used_features if f in top_features)
    return top_count, len(used_features)

top_count, total_nodes = top_features_in_top_levels(dt_classifier_eval, top_15_indices)
print(f"\nTop 15 dimensions used in {top_count}/{total_nodes} nodes in top 4 levels "
      f"({top_count/total_nodes*100:.2f}%)")

# ==================== 9. Perturbation Test (Modified for Stable Confidence Focus) ====================
unique_labels = np.unique(label_ids)
target_texts_info = {}
samples_per_class = 2

for lab in unique_labels:
    indices = np.where(label_ids == lab)[0]
    if len(indices) > 0:
        chosen = sample(list(indices), min(samples_per_class, len(indices)))
        class_name = le.inverse_transform([lab])[0]
        for k, idx in enumerate(chosen, 1):
            target_texts_info[f"class_{lab}_{class_name}_sample{k}"] = idx

print(f"Randomly selected target samples: {len(target_texts_info)}")

# Stable confidence filter setup
stable_threshold = 0.05  # Configurable: |Confidence_Change| < this = "stable" (e.g., 5%)
print(f"Filtering for stable confidence: |change| < {stable_threshold}")

dt_classifier_analysis = dt_classifier_eval
perturbation_strengths = np.linspace(-2.0, 2.0, 9).tolist()
results_list = []  # All perturbations
stable_confidence_results_list = []  # Filtered: Only stable confidence cases

total_iterations = len(target_texts_info) * len(top_15_dimensions) * (len(perturbation_strengths) - 1)

with tqdm(total=total_iterations, desc="Perturbation Testing") as pbar:
    for text_type, text_index in target_texts_info.items():
        original_text = texts[text_index]
        original_latent_vector = latent_vectors[text_index]
        original_proba = dt_classifier_analysis.predict_proba(original_latent_vector.reshape(1, -1))[0]
        original_class_idx = int(np.argmax(original_proba))
        original_confidence = float(original_proba[original_class_idx])
        original_label = le.inverse_transform([original_class_idx])[0]

        for dim_name, importance in top_15_dimensions.items():
            dim_index = int(dim_name.split(' ')[1])
            for strength in perturbation_strengths:
                if strength == 0.0: 
                    continue
                perturbed_latent_vector = np.copy(original_latent_vector)
                perturbed_latent_vector[dim_index] += strength

                perturbed_proba = dt_classifier_analysis.predict_proba(perturbed_latent_vector.reshape(1, -1))[0]
                perturbed_class_idx = int(np.argmax(perturbed_proba))
                perturbed_confidence = float(perturbed_proba[perturbed_class_idx])
                perturbed_label = le.inverse_transform([perturbed_class_idx])[0]
                confidence_change = perturbed_confidence - original_confidence
                prediction_flip = perturbed_label != original_label
                significant_change = abs(confidence_change) > stable_threshold  # Now uses threshold
                is_stable_confidence = abs(confidence_change) < stable_threshold  # New: Stable flag

                # Modified: Cosine similarity in LATENT SPACE (no decode/recon needed)
                similarities = cosine_similarity(perturbed_latent_vector.reshape(1, -1), latent_vectors)
                # Modified: Find best match, but ensure it's not the original (self)
                indices = np.argsort(similarities[0])[::-1]  # Descending order of similarity indices
                best_match_index = indices[0]
                if best_match_index == text_index:  # If best is self, take second best
                    best_match_index = indices[1] if len(indices) > 1 else text_index  # Fallback to self if only one sample
                cosine_sim = float(similarities[0][best_match_index])
                perturbed_text = texts[best_match_index]

                result_entry = {
                    "Test_Type": text_type,
                    "Original_Text_Index": text_index,
                    "Perturbed_Dimension": dim_name,
                    "Dimension_Importance": f"{importance:.6f}",
                    "Perturbation_Strength": strength,
                    "Original_Prediction": original_label,
                    "Original_Confidence": f"{original_confidence:.6f}",
                    "Perturbed_Prediction": perturbed_label,
                    "Perturbed_Confidence": f"{perturbed_confidence:.6f}",
                    "Confidence_Change": f"{confidence_change:.6f}",
                    "Prediction_Flip": prediction_flip,
                    "Significant_Change": significant_change,
                    "Stable_Confidence": is_stable_confidence,  # New: Explicit stable flag
                    "Cosine_Similarity_to_Best_Match": f"{cosine_sim:.6f}",  # Now in latent space, non-self match
                    "Original_Text": original_text,
                    "Perturbed_Text": perturbed_text,
                }

                results_list.append(result_entry)  # All cases

                if is_stable_confidence:
                    stable_confidence_results_list.append(result_entry)  # Filtered

                pbar.update(1)

# Helper function for numeric extraction
def extract_numeric(series):
    return pd.to_numeric(series.str.extract('(\-?\d+\.?\d*)')[0])

# Compute and print summaries (focus on stable confidence flips)
if results_list:
    results_df = pd.DataFrame(results_list)
    stable_df = pd.DataFrame(stable_confidence_results_list) if stable_confidence_results_list else pd.DataFrame()

    # Overall summaries
    total_perturbations = len(results_df)
    stable_count = len(stable_df)
    stable_rate = (stable_count / total_perturbations * 100) if total_perturbations > 0 else 0

    # Focus: Flips under stable confidence
    stable_flips = stable_df['Prediction_Flip'].sum() if not stable_df.empty else 0
    stable_flip_rate = (stable_flips / stable_count * 100) if stable_count > 0 else 0
    all_flip_rate = (results_df['Prediction_Flip'].sum() / total_perturbations * 100)

    summary_stats = {
        'Total_Perturbations': total_perturbations,
        'Stable_Confidence_Cases': stable_count,
        'Stable_Confidence_Rate_%': round(stable_rate, 2),
        'All_Prediction_Flip_Rate_%': round(all_flip_rate, 2),
        'Stable_Confidence_Flip_Rate_%': round(stable_flip_rate, 2),  # Key metric: Focus here
        'Avg_Confidence_Change_All': round(extract_numeric(results_df['Confidence_Change']).mean(), 4),
        'Avg_Cosine_Similarity_All': round(extract_numeric(results_df['Cosine_Similarity_to_Best_Match']).mean(), 4),
    }

    print("\n=== Perturbation Test Summary (Stable Confidence Focus) ===")
    for key, value in summary_stats.items():
        print(f"{key}: {value}")

    if not stable_df.empty:
        # Per-dimension flip rate UNDER stable confidence
        stable_flip_rate_per_dim = stable_df.groupby('Perturbed_Dimension')['Prediction_Flip'].mean() * 100
        print("\nStable-Confidence Prediction Flip Rate per Dimension (%):")
        print(stable_flip_rate_per_dim.sort_values(ascending=False))

        # Per-class (sample) flip rate UNDER stable confidence
        stable_flip_rate_per_class = stable_df.groupby('Test_Type')['Prediction_Flip'].mean() * 100
        print("\nStable-Confidence Prediction Flip Rate per Sample Class (%):")
        print(stable_flip_rate_per_class.sort_values(ascending=False))

        # Highlight top stable-confidence flips (focus of analysis)
        top_stable_flips = stable_df[stable_df['Prediction_Flip'] == True].head(10)
        if not top_stable_flips.empty:
            print(f"\nTop {len(top_stable_flips)} Stable-Confidence Prediction Flips (Analysis Focus):")
            for idx, row in top_stable_flips.iterrows():
                print(f"- {row['Test_Type']}: Dim {row['Perturbed_Dimension']}, Strength {row['Perturbation_Strength']:.2f} "
                      f"| Orig: {row['Original_Prediction']} (Conf: {row['Original_Confidence']}) "
                      f"-> Pert: {row['Perturbed_Prediction']} (Conf: {row['Perturbed_Confidence']}, Change: {row['Confidence_Change']})")
        else:
            print("\nNo stable-confidence prediction flips found. Model is robust under this threshold.")
            # Fallback: Show top all flips
            top_all_flips = results_df[results_df['Prediction_Flip'] == True].head(5)
            if not top_all_flips.empty:
                print("Fallback: Top 5 All Prediction Flips:")
                for idx, row in top_all_flips.iterrows():
                    print(f"- {row['Test_Type']}: ... (Conf Change: {row['Confidence_Change']})")
    else:
        print("\nNo stable-confidence cases found. Try lowering the threshold.")

# Visualizations (focus on stable confidence)
if stable_confidence_results_list:
    stable_numeric = stable_df.copy()
    stable_numeric['Confidence_Change'] = extract_numeric(stable_numeric['Confidence_Change'])
    stable_numeric['Cosine_Similarity_to_Best_Match'] = extract_numeric(stable_numeric['Cosine_Similarity_to_Best_Match'])
    stable_numeric['Perturbation_Strength'] = stable_numeric['Perturbation_Strength'].astype(float)

    # Plot 1: Confidence Change in Stable Cases (should be near zero)
    plt.figure(figsize=(10, 6))
    plt.hist(stable_numeric['Confidence_Change'], bins=20, alpha=0.7, edgecolor='black', color='lightblue')
    plt.axvline(x=0, color='red', linestyle='--', label='Zero Change')
    plt.axvline(x=stable_threshold, color='orange', linestyle='--', label=f'Stable Threshold ({stable_threshold})')
    plt.axvline(x=-stable_threshold, color='orange', linestyle='--')
    plt.xlabel('Confidence Change')
    plt.ylabel('Frequency (Stable Cases Only)')
    plt.title('Distribution of Confidence Changes (Stable Cases)')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.savefig(os.path.join(save_dir, 'stable_confidence_changes_hist.png'), dpi=300, bbox_inches='tight')
    plt.show()

    # Plot 2: Stable-Confidence Flips vs. Strength (per dimension) - Adjusted for 15 dims (3x5 subplots)
    plt.figure(figsize=(15, 12))
    for i, dim in enumerate(top_15_dimensions.keys(), 1):
        plt.subplot(3, 5, i)
        dim_stable_data = stable_numeric[stable_numeric['Perturbed_Dimension'] == dim]
        flip_means = dim_stable_data.groupby('Perturbation_Strength')['Prediction_Flip'].mean()
        plt.plot(flip_means.index, flip_means.values, 'ro-', label='Flip Rate (Stable Conf)')
        plt.xlabel('Perturbation Strength')
        plt.ylabel('Flip Rate')
        plt.title(f'Dim {dim.split(" ")[1]} (Stable Conf Focus)')
        plt.grid(True, alpha=0.3)
        plt.ylim(0, 1)
    plt.tight_layout()
    plt.savefig(os.path.join(save_dir, 'stable_confidence_flips_per_dim.png'), dpi=300, bbox_inches='tight')
    plt.show()

    # Plot 3: Flips Heatmap for Stable Cases
    pivot_stable_flips = stable_numeric.pivot_table(values='Prediction_Flip', index='Perturbation_Strength', 
                                                   columns='Perturbed_Dimension', aggfunc='mean')
    plt.figure(figsize=(16, 10))  # Wider for 15 dims
    sns.heatmap(pivot_stable_flips, annot=True, cmap='Reds', fmt='.2f', cbar_kws={'label': 'Flip Rate (Stable Conf)'})
    plt.title('Stable-Confidence Prediction Flip Rate: Strength vs. Dimension')
    plt.xlabel('Latent Dimension')
    plt.ylabel('Perturbation Strength')
    plt.savefig(os.path.join(save_dir, 'stable_confidence_flip_heatmap.png'), dpi=300, bbox_inches='tight')
    plt.show()

# Additional visualizations for all cases (for completeness)
results_numeric = results_df.copy()
results_numeric['Confidence_Change'] = extract_numeric(results_numeric['Confidence_Change'])
results_numeric['Cosine_Similarity_to_Best_Match'] = extract_numeric(results_numeric['Cosine_Similarity_to_Best_Match'])
results_numeric['Perturbation_Strength'] = results_numeric['Perturbation_Strength'].astype(float)

# Plot 4: Confidence Change vs. Perturbation Strength (all cases, per dimension) - Adjusted for 15 dims
plt.figure(figsize=(15, 12))
for i, dim in enumerate(top_15_dimensions.keys(), 1):
    plt.subplot(3, 5, i)
    dim_data = results_numeric[results_numeric['Perturbed_Dimension'] == dim]
    plt.plot(dim_data['Perturbation_Strength'], dim_data['Confidence_Change'], 'o-', label='Confidence Change')
    plt.axhline(y=0, color='r', linestyle='--', alpha=0.5)
    plt.xlabel('Perturbation Strength')
    plt.ylabel('Confidence Change')
    plt.title(f'Dim {dim.split(" ")[1]} (Imp: {top_15_dimensions[dim]:.4f})')
    plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(os.path.join(save_dir, 'perturbation_confidence_plots_all.png'), dpi=300, bbox_inches='tight')
plt.show()

# Plot 5: Prediction Flips Heatmap (all cases)
pivot_flips = results_numeric.pivot_table(values='Prediction_Flip', index='Perturbation_Strength', 
                                         columns='Perturbed_Dimension', aggfunc='mean')
plt.figure(figsize=(16, 10))  # Wider for 15 dims
sns.heatmap(pivot_flips, annot=True, cmap='Reds', fmt='.2f', cbar_kws={'label': 'Flip Rate'})
plt.title('All Prediction Flip Rate: Perturbation Strength vs. Dimension')
plt.xlabel('Latent Dimension')
plt.ylabel('Perturbation Strength')
plt.savefig(os.path.join(save_dir, 'perturbation_flip_heatmap_all.png'), dpi=300, bbox_inches='tight')
plt.show()

# Plot 6: Cosine Similarity Distribution (all cases) - Updated title for latent space
plt.figure(figsize=(10, 6))
plt.hist(results_numeric['Cosine_Similarity_to_Best_Match'], bins=20, alpha=0.7, edgecolor='black')
plt.xlabel('Cosine Similarity to Best-Match (Latent Space, Non-Self)')
plt.ylabel('Frequency')
plt.title('Distribution of Perturbed Reconstruction Similarity (Latent Space, Non-Self Match)')
plt.grid(True, alpha=0.3)
plt.savefig(os.path.join(save_dir, 'perturbation_similarity_hist_all.png'), dpi=300, bbox_inches='tight')
plt.show()

# Save perturbation results with enhancements
if results_list:
    results_df = pd.DataFrame(results_list)
    stable_df = pd.DataFrame(stable_confidence_results_list) if stable_confidence_results_list else pd.DataFrame()
    results_output_path = os.path.join(save_dir, "perturbation_stable_confidence_analysis_top15_latent_non_self.xlsx")  # Updated filename to reflect non-self match

    try:
        with pd.ExcelWriter(results_output_path, engine='openpyxl') as writer:
            # Primary: Stable confidence sheet (analysis focus)
            if not stable_df.empty:
                stable_df.to_excel(writer, sheet_name='Stable_Confidence_Results', index=False)
                # Highlight flips in stable sheet (yellow)
                worksheet = writer.sheets['Stable_Confidence_Results']
                yellow_fill = PatternFill(start_color='FFFF00', end_color='FFFF00', fill_type='solid')
                bold_font = Font(bold=True)
                for row in range(2, len(stable_df) + 2):
                    if stable_df.iloc[row-2]['Prediction_Flip'] == True:
                        flip_col = stable_df.columns.get_loc('Prediction_Flip') + 1
                        worksheet.cell(row=row, column=flip_col).fill = yellow_fill
                        worksheet.cell(row=row, column=flip_col).font = bold_font
            else:
                pd.DataFrame({'Note': ['No stable-confidence cases found.']}).to_excel(writer, sheet_name='Stable_Confidence_Results', index=False)

            # Secondary: All results for reference
            results_df.to_excel(writer, sheet_name='All_Results', index=False)

            # Summary sheet
            summary_df = pd.DataFrame(list(summary_stats.items()), columns=['Metric', 'Value'])
            summary_df.to_excel(writer, sheet_name='Summary_Stats', index=False)

            # Stable flip rates sheet
            if not stable_df.empty:
                stable_flip_df = pd.DataFrame({'Dimension': stable_flip_rate_per_dim.index, 'Stable_Flip_Rate_%': stable_flip_rate_per_dim.values})
                stable_flip_df.to_excel(writer, sheet_name='Stable_Flip_Rate_Per_Dim', index=False)

                # All flip rates sheet (if defined)
                if 'flip_rate_per_dim' in locals():
                    all_flip_df = pd.DataFrame({'Dimension': flip_rate_per_dim.index, 'All_Flip_Rate_%': flip_rate_per_dim.values})
                    all_flip_df.to_excel(writer, sheet_name='All_Flip_Rate_Per_Dim', index=False)

        print(f"\nStable-Confidence Focused Results Saved to:\n{results_output_path}")
        print("  - Sheets: Stable_Confidence_Results (primary, with highlights), All_Results, Summary_Stats, Stable_Flip_Rate_Per_Dim")
        print("  - Plots: stable_confidence_changes_hist.png, stable_confidence_flips_per_dim.png, stable_confidence_flip_heatmap.png")
        print("  - Additional Plots (All Cases): perturbation_confidence_plots_all.png, perturbation_flip_heatmap_all.png, perturbation_similarity_hist_all.png")
        print("  - Note: Cosine similarities now computed in LATENT SPACE for efficiency and direct VAE analysis.")
        print("  - Note: Best-match texts exclude the original (self) sample; uses second-best if needed.")

    except Exception as e:
        print(f"Excel save failed: {e}. Falling back to CSV.")
        if not stable_df.empty:
            stable_df.to_csv(os.path.join(save_dir, "stable_confidence_results.csv"), index=False, encoding='utf-8-sig')
        results_df.to_csv(os.path.join(save_dir, "all_perturbation_results.csv"), index=False, encoding='utf-8-sig')
        summary_df.to_csv(os.path.join(save_dir, "summary_stats.csv"), index=False)
        print(f"Saved CSVs in {save_dir}/")

# Save VAE model and scaler
model_path = os.path.join(save_dir, "vae_model.pt")
scaler_path = os.path.join(save_dir, "scaler.pkl")
torch.save(vae.state_dict(), model_path)
with open(scaler_path, 'wb') as f:
    pickle.dump(scaler, f)
print(f"\nVAE model and scaler saved to {save_dir}/")